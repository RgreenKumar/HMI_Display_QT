#!/usr/bin/env python3
import argparse
import json
import math
import random
import sys
import threading
import time

import serial


DEFAULT_RANGES = {
    "speed": {"min": 0.0, "max": 60.0},
    "rpm": {"min": 1000.0, "max": 5000.0},
    "temperature": {"min": 30.0, "max": 90.0},
    "battery": {"min": 11.5, "max": 14.5},
    "fuel": {"min": 20.0, "max": 100.0},
    "pressure": {"min": 20.0, "max": 40.0},
}

PARAMETERS = set(DEFAULT_RANGES.keys())


class Simulator:
    """Simple stateful EV simulator: values are coupled, not independently random."""
    def __init__(self, ser):
        self.ser = ser
        self.ranges = {k: v.copy() for k, v in DEFAULT_RANGES.items()}
        self.running = True
        self.enabled = False
        self.mode = "ECO"
        self.mode_speed_limits = {"ECO": 40.0, "POWER": 60.0, "CRUISE": 50.0}
        self.speed = 0.0
        self.rpm = 1000.0
        self.temperature = 30.0
        self.battery = 13.0
        self.fuel = 80.0
        self.pressure = 32.0
        self.trip = 0.0
        self.odo = 200.0
        self.range_value = 50.0
        self.lock = threading.RLock()
        self.last_tick = time.monotonic()

    def send(self, obj):
        line = (json.dumps(obj, separators=(",", ":")) + "\n").encode("utf-8")
        try:
            self.ser.write(line)
        except (serial.SerialException, OSError) as exc:
            print(f"UART write error: {exc}", file=sys.stderr, flush=True)

    def set_range(self, parameter, minimum, maximum):
        if parameter not in PARAMETERS:
            raise ValueError("unknown parameter")
        minimum, maximum = float(minimum), float(maximum)
        if minimum >= maximum:
            raise ValueError("minimum must be less than maximum")
        if minimum < -1000000 or maximum > 1000000:
            raise ValueError("range out of bounds")
        with self.lock:
            self.ranges[parameter] = {"min": minimum, "max": maximum}
            if parameter == "speed":
                for mode in self.mode_speed_limits:
                    self.mode_speed_limits[mode] = max(minimum, min(maximum, self.mode_speed_limits[mode]))
            # Keep the current simulated values valid after a range change.
            attr = {"speed":"speed", "rpm":"rpm", "temperature":"temperature",
                    "battery":"battery", "fuel":"fuel", "pressure":"pressure"}[parameter]
            setattr(self, attr, max(minimum, min(maximum, getattr(self, attr))))

    def telemetry(self):
        with self.lock:
            now = time.monotonic()
            dt = min(max(now - self.last_tick, 0.0), 0.25)
            self.last_tick = now
            speed_range = self.ranges["speed"]
            target_max = min(speed_range["max"], self.mode_speed_limits.get(self.mode, speed_range["max"]))
            if not self.enabled:
                target_speed = 0.0
            else:
                # A gentle changing target speed, with mode-dependent behavior.
                phase = now * (0.20 if self.mode == "ECO" else 0.32 if self.mode == "POWER" else 0.12)
                wave = (math.sin(phase) + 1.0) / 2.0
                target_speed = speed_range["min"] + wave * (target_max - speed_range["min"])
                if self.mode == "ECO": target_speed *= 0.65
                elif self.mode == "CRUISE": target_speed = speed_range["min"] + 0.60 * (target_max-speed_range["min"])
            # Smooth acceleration/braking instead of instant random jumps.
            rate = 12.0 if target_speed > self.speed else 20.0
            delta = max(-rate * dt, min(rate * dt, target_speed - self.speed))
            self.speed = max(0.0, min(target_max, self.speed + delta))
            rr = self.ranges["rpm"]
            speed_fraction = self.speed / max(target_max, 1.0)
            self.rpm = rr["min"] + speed_fraction * (rr["max"] - rr["min"])
            tr = self.ranges["temperature"]
            target_temp = tr["min"] + speed_fraction * (tr["max"] - tr["min"]) * 0.65
            self.temperature += (target_temp - self.temperature) * min(dt / 25.0, 1.0)
            br = self.ranges["battery"]
            # Battery voltage sags slightly under load and recovers when stopped.
            target_battery = br["max"] - speed_fraction * (br["max"] - br["min"]) * 0.55
            self.battery += (target_battery - self.battery) * min(dt / 3.0, 1.0)
            fr = self.ranges["fuel"]
            self.fuel = max(fr["min"], min(fr["max"], self.fuel - (0.00008 * self.speed * dt if self.enabled else 0)))
            pr = self.ranges["pressure"]
            target_pressure = pr["min"] + 0.5 * (pr["max"] - pr["min"]) + speed_fraction * 0.03 * (pr["max"]-pr["min"])
            self.pressure += (target_pressure - self.pressure) * min(dt / 8.0, 1.0)
            distance = self.speed * dt / 3600.0
            if self.enabled:
                self.trip += distance
                self.odo += distance
            # Estimated range responds to remaining fuel and current consumption.
            fuel_span = max(fr["max"] - fr["min"], 1.0)
            self.range_value = max(0.0, (self.fuel - fr["min"]) / fuel_span * 100.0)
            return {"type":"telemetry", "speed":round(self.speed,1), "rpm":round(self.rpm),
                    "temperature":round(self.temperature,1), "battery":round(self.battery,2),
                    "fuel":round(self.fuel,1), "pressure":round(self.pressure,1),
                    "range":round(self.range_value,1), "odo":round(self.odo,2),
                    "trip":round(self.trip,2), "mode":self.mode, "running":self.enabled,
                    "mode_speed_limit":round(self.mode_speed_limits.get(self.mode, target_max),1)}

    def handle(self, message):
        command = message.get("command")
        if command == "set_range":
            self.set_range(message.get("parameter"), message.get("min"), message.get("max"))
            self.send({"type":"ack", "command":"set_range", "parameter":message["parameter"],
                       "min":float(message["min"]), "max":float(message["max"])})
        elif command == "set_mode_speed_limit":
            mode = str(message.get("mode", "ECO")).upper()
            limit = float(message.get("limit"))
            if mode not in {"ECO", "POWER", "CRUISE"}: raise ValueError("invalid mode")
            if limit < self.ranges["speed"]["min"] or limit > self.ranges["speed"]["max"]:
                raise ValueError("mode speed limit must be inside the speed range")
            with self.lock: self.mode_speed_limits[mode] = limit
            self.send({"type":"ack", "command":"set_mode_speed_limit", "mode":mode, "limit":limit})
        elif command == "set_mode":
            mode = str(message.get("mode", "ECO")).upper()
            if mode not in {"ECO", "POWER", "CRUISE"}: raise ValueError("invalid mode")
            with self.lock: self.mode = mode
            self.send({"type":"ack", "command":"set_mode", "mode":mode})
        elif command == "start":
            with self.lock: self.enabled = True
            self.send({"type":"ack", "command":"start"})
        elif command == "stop":
            with self.lock: self.enabled = False
            self.send({"type":"ack", "command":"stop"})
        elif command == "reset_trip":
            with self.lock: self.trip = 0.0
            self.send({"type":"ack", "command":"reset_trip"})
        elif command == "get_ranges":
            with self.lock: current = {k:v.copy() for k,v in self.ranges.items()}
            self.send({"type":"ranges", "ranges":current})
        else:
            raise ValueError(f"unknown command: {command}")

    def receive_loop(self):
        while self.running:
            try:
                raw = self.ser.readline()
                if not raw: continue
                try:
                    message = json.loads(raw.decode("utf-8").strip())
                    self.handle(message)
                except (ValueError, json.JSONDecodeError, TypeError, KeyError) as exc:
                    self.send({"type":"error", "message":str(exc)})
            except (serial.SerialException, OSError) as exc:
                print(f"UART read error: {exc}", file=sys.stderr, flush=True)
                break

    def telemetry_loop(self):
        # Send telemetry even while stopped, so the dashboard always has live values.
        while self.running:
            self.send(self.telemetry())
            time.sleep(0.2)

def main():
    parser = argparse.ArgumentParser(description="EV HMI UART simulation backend")
    parser.add_argument("--port", required=True, help="Serial port, e.g. /dev/pts/5 or /dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=115200)
    args = parser.parse_args()

    try:
        ser = serial.Serial(args.port, args.baud, timeout=0.2)
    except serial.SerialException as exc:
        print(f"Could not open {args.port}: {exc}", file=sys.stderr)
        sys.exit(1)

    simulator = Simulator(ser)
    print(f"Backend running on {args.port} @ {args.baud}", flush=True)
    print("Sending live telemetry every 200 ms; press START in the dashboard.", flush=True)

    rx = threading.Thread(target=simulator.receive_loop, daemon=True)
    tx = threading.Thread(target=simulator.telemetry_loop, daemon=True)
    rx.start()
    tx.start()

    try:
        while rx.is_alive():
            time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        simulator.running = False
        ser.close()


if __name__ == "__main__":
    main()
