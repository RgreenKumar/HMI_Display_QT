#include "gaugewidget.h"

#include <QPainter>
#include <QPaintEvent>
#include <QPen>
#include <QtMath>

GaugeWidget::GaugeWidget(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(430, 430);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
}

void GaugeWidget::setValue(double value)
{
    m_value = qBound(0.0, value, m_maximum);
    update();
}

void GaugeWidget::setAccentColor(const QColor &color)
{
    m_accentColor = color;
    update();
}

void GaugeWidget::setMaximum(double maximum)
{
    m_maximum = qMax(1.0, maximum);
    m_value = qBound(0.0, m_value, m_maximum);
    update();
}

void GaugeWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);

    const QRectF r = rect();
    const QPointF c = r.center();
    const double radius = qMin(r.width(), r.height()) * 0.36;

    // Background.
    p.fillRect(r, QColor("#101112"));

    // Gauge geometry: 225 degrees through 315 degrees in Qt's coordinate system.
    // We draw from lower-left around the top to lower-right.
    const QRectF arcRect(c.x() - radius, c.y() - radius,
                         radius * 2.0, radius * 2.0);

    QPen basePen(QColor("#d8d9db"), 7, Qt::SolidLine, Qt::RoundCap);
    p.setPen(basePen);
    p.drawArc(arcRect, 225 * 16, -270 * 16);

    QPen redPen(m_accentColor, 17, Qt::SolidLine, Qt::RoundCap);
    p.setPen(redPen);
    const double fraction = m_maximum > 0.0 ? m_value / m_maximum : 0.0;
    p.drawArc(arcRect, 225 * 16, int(-270.0 * fraction * 16.0));

    // Tick marks and labels.
    p.setPen(QPen(QColor("#e0e1e2"), 2));
    QFont tickFont = font();
    tickFont.setPointSize(12);
    p.setFont(tickFont);

    const int tickCount = 7;
    for (int i = 0; i < tickCount; ++i) {
        const double frac = double(i) / double(tickCount - 1);
        const double angleDeg = 135.0 + frac * 270.0;
        const double angle = qDegreesToRadians(angleDeg);

        QPointF outer(c.x() + qCos(angle) * (radius + 7),
                      c.y() + qSin(angle) * (radius + 7));
        QPointF inner(c.x() + qCos(angle) * (radius - 16),
                      c.y() + qSin(angle) * (radius - 16));
        p.drawLine(inner, outer);

        QString label = QString::number(m_maximum * frac, 'f', 0);
        QRectF lr(c.x() + qCos(angle) * (radius + 33) - 24,
                  c.y() + qSin(angle) * (radius + 33) - 14, 48, 28);
        p.drawText(lr, Qt::AlignCenter, label);
    }

    // Center value.
    p.setPen(QColor("#f3f3f3"));
    QFont valueFont = font();
    valueFont.setPointSize(48);
    valueFont.setBold(true);
    p.setFont(valueFont);
    p.drawText(QRectF(c.x() - 120, c.y() - 35, 240, 70),
               Qt::AlignCenter, QString::number(m_value, 'f', 0));

    QFont unitFont = font();
    unitFont.setPointSize(15);
    p.setFont(unitFont);
    p.setPen(QColor("#c8c9ca"));
    p.drawText(QRectF(c.x() - 80, c.y() + 35, 160, 30),
               Qt::AlignCenter, "Km/h");

    // Needle.
    const double needleAngleDeg = 135.0 + fraction * 270.0;
    const double needleAngle = qDegreesToRadians(needleAngleDeg);
    QPointF tip(c.x() + qCos(needleAngle) * (radius - 28),
                c.y() + qSin(needleAngle) * (radius - 28));

    p.setPen(QPen(QColor("#eeeeee"), 4, Qt::SolidLine, Qt::RoundCap));
    p.drawLine(c, tip);
    p.setBrush(QColor("#eeeeee"));
    p.drawEllipse(c, 7, 7);
}
