#pragma once

#include <QMainWindow>
#include <QMap>
#include <QSerialPort>
#include <QColor>

#include "settingsdialog.h"

class QLabel;
class QPushButton;
class GaugeWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(const QString &portName, int baudRate,
                        QWidget *parent = nullptr);

private slots:
    void readSerial();
    void serialError(QSerialPort::SerialPortError error);
    void showSettings();
    void applyRanges(const QMap<QString, RangeValue> &ranges,
                     const QMap<QString, double> &modeSpeedLimits);
    void startSimulation();
    void stopSimulation();
    void setMode(const QString &mode);

private:
    void buildUi();
    void sendJson(const QJsonObject &object);
    void updateTelemetry(const QJsonObject &object);
    void updateConnectionStatus(const QString &text, bool good);
    void applyModeTheme(const QString &mode);
    QColor modeColor(const QString &mode) const;

    QSerialPort m_serial;
    QString m_portName;
    int m_baudRate;

    GaugeWidget *m_gauge = nullptr;
    QLabel *m_timeLabel = nullptr;
    QLabel *m_batteryLabel = nullptr;
    QLabel *m_rangeLabel = nullptr;
    QLabel *m_odoLabel = nullptr;
    QLabel *m_tripLabel = nullptr;
    QLabel *m_rpmLabel = nullptr;
    QLabel *m_temperatureLabel = nullptr;
    QLabel *m_fuelLabel = nullptr;
    QLabel *m_pressureLabel = nullptr;
    QLabel *m_statusLabel = nullptr;
    QLabel *m_modeLabel = nullptr;

    QPushButton *m_ecoButton = nullptr;
    QPushButton *m_powerButton = nullptr;
    QPushButton *m_cruiseButton = nullptr;
    QPushButton *m_startButton = nullptr;
    QPushButton *m_stopButton = nullptr;
    QPushButton *m_settingsButton = nullptr;

    QMap<QString, RangeValue> m_ranges;
    QMap<QString, double> m_modeSpeedLimits;
    QString m_currentMode = "ECO";
};
