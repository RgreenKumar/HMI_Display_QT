#include "settingsdialog.h"

#include <QDoubleSpinBox>
#include <QGridLayout>
#include <QGroupBox>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QtGlobal>

SettingsDialog::SettingsDialog(const QMap<QString, RangeValue> &ranges,
                               const QMap<QString, double> &modeSpeedLimits,
                               QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("Simulation Settings");
    setModal(true);
    resize(620, 650);

    auto *title = new QLabel("SIMULATION SETTINGS");
    title->setObjectName("settingsTitle");

    auto *grid = new QGridLayout;
    grid->setHorizontalSpacing(18);
    grid->setVerticalSpacing(12);
    grid->addWidget(new QLabel("PARAMETER"), 0, 0);
    grid->addWidget(new QLabel("MINIMUM"), 0, 1);
    grid->addWidget(new QLabel("MAXIMUM"), 0, 2);

    const QStringList names = {
        "speed", "rpm", "temperature", "battery", "fuel", "pressure"
    };
    const QMap<QString, QString> labels = {
        {"speed", "Speed (Km/h)"},
        {"rpm", "RPM"},
        {"temperature", "Temperature (°C)"},
        {"battery", "Battery (V)"},
        {"fuel", "Fuel (%)"},
        {"pressure", "Pressure (PSI)"}
    };

    for (int row = 0; row < names.size(); ++row) {
        const QString key = names.at(row);
        auto *label = new QLabel(labels.value(key));
        auto *minBox = new QDoubleSpinBox;
        auto *maxBox = new QDoubleSpinBox;

        minBox->setRange(-1000000.0, 1000000.0);
        maxBox->setRange(-1000000.0, 1000000.0);
        minBox->setDecimals(key == "rpm" ? 0 : 2);
        maxBox->setDecimals(key == "rpm" ? 0 : 2);
        minBox->setSingleStep(key == "rpm" ? 100.0 : 0.1);
        maxBox->setSingleStep(key == "rpm" ? 100.0 : 0.1);

        const auto it = ranges.find(key);
        if (it != ranges.end()) {
            minBox->setValue(it->minimum);
            maxBox->setValue(it->maximum);
        }

        grid->addWidget(label, row + 1, 0);
        grid->addWidget(minBox, row + 1, 1);
        grid->addWidget(maxBox, row + 1, 2);
        m_minBoxes.insert(key, minBox);
        m_maxBoxes.insert(key, maxBox);
    }

    auto *modeGroup = new QGroupBox("MODE SPEED LIMITS");
    auto *modeGrid = new QGridLayout(modeGroup);
    modeGrid->addWidget(new QLabel("Mode"), 0, 0);
    modeGrid->addWidget(new QLabel("Maximum speed (Km/h)"), 0, 1);

    const QStringList modes = {"ECO", "POWER", "CRUISE"};
    for (int row = 0; row < modes.size(); ++row) {
        const QString mode = modes.at(row);
        auto *label = new QLabel(mode);
        auto *box = new QDoubleSpinBox;
        box->setRange(1.0, 1000.0);
        box->setDecimals(0);
        box->setSingleStep(1.0);
        const double speedMax = ranges.value("speed", RangeValue{0,60}).maximum;
        box->setValue(qMin(modeSpeedLimits.value(mode, speedMax), speedMax));
        modeGrid->addWidget(label, row + 1, 0);
        modeGrid->addWidget(box, row + 1, 1);
        m_modeLimitBoxes.insert(mode, box);
    }

    auto *hint = new QLabel("The active mode will never accelerate above its configured speed limit.");
    hint->setObjectName("hint");
    hint->setWordWrap(true);

    auto *applyButton = new QPushButton("APPLY");
    auto *cancelButton = new QPushButton("CANCEL");
    applyButton->setObjectName("primaryButton");
    cancelButton->setObjectName("secondaryButton");
    connect(applyButton, &QPushButton::clicked, this, &SettingsDialog::apply);
    connect(cancelButton, &QPushButton::clicked, this, &QDialog::reject);

    auto *buttons = new QHBoxLayout;
    buttons->addStretch();
    buttons->addWidget(cancelButton);
    buttons->addWidget(applyButton);

    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(26, 24, 26, 24);
    layout->setSpacing(12);
    layout->addWidget(title);
    layout->addWidget(new QLabel("General simulation ranges"));
    layout->addLayout(grid);
    layout->addSpacing(8);
    layout->addWidget(modeGroup);
    layout->addWidget(hint);
    layout->addStretch();
    layout->addLayout(buttons);

    setStyleSheet(R"(
        QDialog { background: #111214; color: #eeeeee; }
        QLabel { color: #d8d9da; font-size: 14px; }
        #settingsTitle { color: #ffffff; font-size: 21px; font-weight: 700; letter-spacing: 1px; }
        #hint { color: #8f9296; font-size: 12px; }
        QGroupBox { color: #ffffff; border: 1px solid #3b3e43; border-radius: 6px; margin-top: 10px; padding-top: 12px; font-weight: 700; }
        QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; }
        QDoubleSpinBox { background: #1b1d20; color: #ffffff; border: 1px solid #42454a; border-radius: 4px; padding: 8px; min-height: 26px; }
        QDoubleSpinBox:focus { border: 1px solid #5b8cff; }
        QPushButton { padding: 10px 24px; border-radius: 4px; font-weight: 700; }
        #primaryButton { background: #2f80ed; color: white; border: none; }
        #secondaryButton { background: #25272a; color: white; border: 1px solid #4b4e53; }
    )");
}

void SettingsDialog::apply()
{
    QMap<QString, RangeValue> result;
    for (const QString &key : m_minBoxes.keys()) {
        const double minimum = m_minBoxes[key]->value();
        const double maximum = m_maxBoxes[key]->value();
        if (minimum >= maximum) {
            QMessageBox::warning(this, "Invalid Range",
                                 QString("%1: minimum must be smaller than maximum.").arg(key));
            return;
        }
        result.insert(key, {minimum, maximum});
    }

    QMap<QString, double> modeLimits;
    for (const QString &mode : m_modeLimitBoxes.keys()) {
        const double limit = m_modeLimitBoxes[mode]->value();
        if (limit < result["speed"].minimum || limit > result["speed"].maximum) {
            QMessageBox::warning(this, "Invalid Speed Limit",
                                 QString("%1 speed limit must be between the Speed minimum and maximum.").arg(mode));
            return;
        }
        modeLimits.insert(mode, limit);
    }

    emit rangesApplied(result, modeLimits);
    accept();
}
