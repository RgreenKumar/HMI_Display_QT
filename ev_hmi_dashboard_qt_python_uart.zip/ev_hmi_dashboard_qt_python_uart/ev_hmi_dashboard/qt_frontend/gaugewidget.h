#pragma once

#include <QColor>
#include <QWidget>

class GaugeWidget : public QWidget
{
    Q_OBJECT

public:
    explicit GaugeWidget(QWidget *parent = nullptr);

    void setValue(double value);
    void setMaximum(double maximum);
    void setAccentColor(const QColor &color);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    double m_value = 0.0;
    double m_maximum = 60.0;
    QColor m_accentColor = QColor("#e53935");
};
