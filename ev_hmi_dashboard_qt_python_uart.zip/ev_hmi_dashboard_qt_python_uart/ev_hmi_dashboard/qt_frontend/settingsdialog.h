#pragma once

#include <QDialog>
#include <QMap>

class QDoubleSpinBox;

struct RangeValue
{
    double minimum;
    double maximum;
};

class SettingsDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SettingsDialog(const QMap<QString, RangeValue> &ranges,
                             const QMap<QString, double> &modeSpeedLimits,
                             QWidget *parent = nullptr);

signals:
    void rangesApplied(const QMap<QString, RangeValue> &ranges,
                       const QMap<QString, double> &modeSpeedLimits);

private slots:
    void apply();

private:
    QMap<QString, QDoubleSpinBox*> m_minBoxes;
    QMap<QString, QDoubleSpinBox*> m_maxBoxes;
    QMap<QString, QDoubleSpinBox*> m_modeLimitBoxes;
};
