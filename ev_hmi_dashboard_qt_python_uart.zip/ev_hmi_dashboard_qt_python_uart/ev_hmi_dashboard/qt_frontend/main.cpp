#include <QApplication>
#include <QCommandLineParser>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName("EV HMI Dashboard");
    QApplication::setApplicationVersion("1.0");

    QCommandLineParser parser;
    parser.setApplicationDescription("EV HMI Dashboard - Qt frontend");
    parser.addHelpOption();

    QCommandLineOption portOption({"p", "port"}, "Serial port.", "port", "/dev/ttyUSB0");
    QCommandLineOption baudOption({"b", "baud"}, "Baud rate.", "baud", "115200");
    parser.addOption(portOption);
    parser.addOption(baudOption);
    parser.process(app);

    MainWindow window(parser.value(portOption), parser.value(baudOption).toInt());
    window.show();

    return app.exec();
}
