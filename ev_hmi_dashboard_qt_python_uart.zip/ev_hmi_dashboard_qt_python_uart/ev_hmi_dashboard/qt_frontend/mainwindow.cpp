#include "mainwindow.h"
#include <QStyle>
#include "gaugewidget.h"

#include <QDateTime>
#include <QHBoxLayout>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QPushButton>
#include <QTimer>
#include <QVBoxLayout>
#include <QWidget>

MainWindow::MainWindow(const QString &portName, int baudRate, QWidget *parent)
    : QMainWindow(parent), m_portName(portName), m_baudRate(baudRate)
{
    m_ranges = {
        {"speed", {0.0, 60.0}}, {"rpm", {1000.0, 5000.0}},
        {"temperature", {30.0, 90.0}}, {"battery", {11.5, 14.5}},
        {"fuel", {20.0, 100.0}}, {"pressure", {20.0, 40.0}}
    };
    m_modeSpeedLimits = {{"ECO", 40.0}, {"POWER", 60.0}, {"CRUISE", 50.0}};

    buildUi();

    m_serial.setPortName(m_portName);
    m_serial.setBaudRate(m_baudRate);
    m_serial.setDataBits(QSerialPort::Data8);
    m_serial.setParity(QSerialPort::NoParity);
    m_serial.setStopBits(QSerialPort::OneStop);
    m_serial.setFlowControl(QSerialPort::NoFlowControl);
    connect(&m_serial, &QSerialPort::readyRead, this, &MainWindow::readSerial);
    connect(&m_serial, &QSerialPort::errorOccurred, this, &MainWindow::serialError);

    if (!m_serial.open(QIODevice::ReadWrite))
        updateConnectionStatus("UART: NOT CONNECTED", false);
    else {
        updateConnectionStatus(QString("UART: %1 @ %2").arg(m_portName).arg(m_baudRate), true);
        sendJson({{"command", "get_ranges"}});
        setMode("ECO");
    }

    auto *clock = new QTimer(this);
    connect(clock, &QTimer::timeout, this, [this]() {
        m_timeLabel->setText(QDateTime::currentDateTime().toString("hh:mm AP"));
    });
    clock->start(1000);
    m_timeLabel->setText(QDateTime::currentDateTime().toString("hh:mm AP"));
}

void MainWindow::buildUi()
{
    setWindowTitle("EV HMI Dashboard");
    resize(1200, 720);
    auto *central = new QWidget;
    setCentralWidget(central);

    m_timeLabel = new QLabel;
    m_batteryLabel = new QLabel("50%");
    m_rangeLabel = new QLabel("50 KM");
    m_odoLabel = new QLabel("200 KM");
    m_tripLabel = new QLabel("0 KM");
    m_rpmLabel = new QLabel("0");
    m_temperatureLabel = new QLabel("0 °C");
    m_fuelLabel = new QLabel("0 %");
    m_pressureLabel = new QLabel("0 PSI");
    m_statusLabel = new QLabel("UART: CONNECTING...");
    m_modeLabel = new QLabel("ECO");
    m_modeLabel->setObjectName("modeIndicator");

    m_gauge = new GaugeWidget;
    m_ecoButton = new QPushButton("ECO");
    m_powerButton = new QPushButton("POWER");
    m_cruiseButton = new QPushButton("CRUISE");
    m_startButton = new QPushButton("START");
    m_stopButton = new QPushButton("STOP");
    m_settingsButton = new QPushButton("⚙  SETTINGS");

    m_ecoButton->setProperty("modeName", "eco");
    m_powerButton->setProperty("modeName", "power");
    m_cruiseButton->setProperty("modeName", "cruise");
    connect(m_ecoButton, &QPushButton::clicked, this, [this]{ setMode("ECO"); });
    connect(m_powerButton, &QPushButton::clicked, this, [this]{ setMode("POWER"); });
    connect(m_cruiseButton, &QPushButton::clicked, this, [this]{ setMode("CRUISE"); });
    connect(m_startButton, &QPushButton::clicked, this, &MainWindow::startSimulation);
    connect(m_stopButton, &QPushButton::clicked, this, &MainWindow::stopSimulation);
    connect(m_settingsButton, &QPushButton::clicked, this, &MainWindow::showSettings);

    auto makeValue = [](const QString &caption, QLabel *value) {
        auto *box = new QVBoxLayout;
        auto *c = new QLabel(caption);
        c->setObjectName("smallCaption");
        value->setObjectName("smallValue");
        box->addWidget(c); box->addWidget(value); return box;
    };

    auto *top = new QHBoxLayout;
    top->addWidget(m_timeLabel); top->addStretch(); top->addWidget(m_modeLabel);
    top->addSpacing(20); top->addWidget(new QLabel("BATTERY")); top->addWidget(m_batteryLabel);

    auto *modes = new QVBoxLayout;
    auto *driveTitle = new QLabel("Drive mode"); driveTitle->setObjectName("sectionTitle");
    modes->addWidget(driveTitle); modes->addWidget(m_ecoButton); modes->addWidget(m_powerButton); modes->addWidget(m_cruiseButton); modes->addStretch();

    auto *right = new QVBoxLayout;
    right->addWidget(new QLabel("RANGE")); right->addWidget(m_rangeLabel); right->addSpacing(18);
    right->addWidget(new QLabel("ODO")); right->addWidget(m_odoLabel); right->addSpacing(18);
    right->addWidget(new QLabel("TRIP")); right->addWidget(m_tripLabel); right->addStretch();

    auto *middle = new QHBoxLayout;
    middle->addLayout(modes, 1); middle->addWidget(m_gauge, 3); middle->addLayout(right, 1);

    auto *stats = new QHBoxLayout;
    stats->addLayout(makeValue("RPM", m_rpmLabel)); stats->addLayout(makeValue("TEMPERATURE", m_temperatureLabel));
    stats->addLayout(makeValue("FUEL", m_fuelLabel)); stats->addLayout(makeValue("PRESSURE", m_pressureLabel));

    auto *bottom = new QHBoxLayout;
    bottom->addWidget(m_statusLabel); bottom->addStretch(); bottom->addWidget(m_startButton); bottom->addWidget(m_stopButton); bottom->addWidget(m_settingsButton);

    auto *mainLayout = new QVBoxLayout(central);
    mainLayout->setContentsMargins(28, 20, 28, 20); mainLayout->setSpacing(12);
    mainLayout->addLayout(top); mainLayout->addWidget(new QLabel("Drive mode")); mainLayout->addLayout(middle, 1); mainLayout->addLayout(stats); mainLayout->addLayout(bottom);

    setStyleSheet(R"(
        QMainWindow, QWidget { background:#101112; color:#eeeeee; font-family:"DejaVu Sans"; }
        QLabel { color:#d7d8d9; }
        #sectionTitle { color:#ffffff; font-size:16px; font-weight:600; }
        #modeIndicator { color:#66d98a; font-size:15px; font-weight:700; }
        #smallCaption { color:#8f9296; font-size:11px; }
        #smallValue { color:#f1f1f1; font-size:15px; font-weight:600; }
        QPushButton { background:#1b1d20; color:#eeeeee; border:1px solid #404349; border-radius:4px; padding:9px 14px; font-weight:600; }
        QPushButton:hover { border:1px solid #777a80; }
        QPushButton:pressed { background:#2a2c30; }
        QPushButton[modeName="eco"][active="true"] { background:#168a45; border:1px solid #37c76f; color:white; }
        QPushButton[modeName="power"][active="true"] { background:#1769aa; border:1px solid #3b9cff; color:white; }
        QPushButton[modeName="cruise"][active="true"] { background:#a71920; border:1px solid #ed454d; color:white; }
        #statusGood { color:#8fd18f; } #statusBad { color:#e28b8b; }
    )");

    applyModeTheme("ECO");
}

QColor MainWindow::modeColor(const QString &mode) const
{
    const QString m = mode.toUpper();
    if (m == "ECO") return QColor("#2ecc71");
    if (m == "POWER") return QColor("#3498db");
    return QColor("#e53935");
}

void MainWindow::applyModeTheme(const QString &mode)
{
    const QString upper = mode.toUpper();
    const QList<QPushButton*> buttons = {m_ecoButton, m_powerButton, m_cruiseButton};
    for (auto *b : buttons) {
        b->setProperty("active", false);
        b->style()->unpolish(b); b->style()->polish(b);
    }
    QPushButton *active = upper == "POWER" ? m_powerButton : upper == "CRUISE" ? m_cruiseButton : m_ecoButton;
    active->setProperty("active", true);
    active->style()->unpolish(active); active->style()->polish(active);
    m_currentMode = upper;
    m_modeLabel->setText(upper + QString("  •  LIMIT %1 KM/h").arg(m_modeSpeedLimits.value(upper, m_ranges["speed"].maximum), 0, 'f', 0));
    m_modeLabel->setStyleSheet(QString("color:%1; font-weight:700;").arg(modeColor(upper).name()));
    m_gauge->setAccentColor(modeColor(upper));
}

void MainWindow::sendJson(const QJsonObject &object)
{
    if (m_serial.isOpen()) m_serial.write(QJsonDocument(object).toJson(QJsonDocument::Compact) + '\n');
}

void MainWindow::readSerial()
{
    while (m_serial.canReadLine()) {
        const QByteArray line = m_serial.readLine().trimmed();
        if (line.isEmpty()) continue;
        QJsonParseError error;
        const QJsonDocument doc = QJsonDocument::fromJson(line, &error);
        if (error.error != QJsonParseError::NoError || !doc.isObject()) continue;
        const QJsonObject obj = doc.object();
        const QString type = obj.value("type").toString();
        if (type == "telemetry") updateTelemetry(obj);
        else if (type == "ranges") {
            const QJsonObject rr = obj.value("ranges").toObject();
            for (const QString &key : rr.keys()) {
                const QJsonObject r = rr.value(key).toObject();
                if (r.contains("min") && r.contains("max")) m_ranges[key] = {r.value("min").toDouble(), r.value("max").toDouble()};
            }
            m_gauge->setMaximum(m_ranges["speed"].maximum);
        } else if (type == "error") updateConnectionStatus("BACKEND ERROR: " + obj.value("message").toString(), false);
    }
}

void MainWindow::updateTelemetry(const QJsonObject &obj)
{
    const double speed = obj.value("speed").toDouble();
    m_gauge->setMaximum(m_ranges["speed"].maximum);
    m_gauge->setValue(speed);
    m_rpmLabel->setText(QString::number(obj.value("rpm").toDouble(), 'f', 0));
    m_temperatureLabel->setText(QString::number(obj.value("temperature").toDouble(), 'f', 1) + " °C");
    m_batteryLabel->setText(QString::number(obj.value("battery").toDouble(), 'f', 1) + " V");
    m_fuelLabel->setText(QString::number(obj.value("fuel").toDouble(), 'f', 0) + " %");
    m_pressureLabel->setText(QString::number(obj.value("pressure").toDouble(), 'f', 1) + " PSI");
    m_rangeLabel->setText(QString::number(obj.value("range").toDouble(), 'f', 0) + " KM");
    m_odoLabel->setText(QString::number(obj.value("odo").toDouble(), 'f', 0) + " KM");
    m_tripLabel->setText(QString::number(obj.value("trip").toDouble(), 'f', 0) + " KM");
    const QString mode = obj.value("mode").toString(m_currentMode);
    if (mode.toUpper() != m_currentMode) applyModeTheme(mode);
}

void MainWindow::showSettings()
{
    SettingsDialog dialog(m_ranges, m_modeSpeedLimits, this);
    connect(&dialog, &SettingsDialog::rangesApplied, this, &MainWindow::applyRanges);
    dialog.exec();
}

void MainWindow::applyRanges(const QMap<QString, RangeValue> &ranges, const QMap<QString, double> &modeSpeedLimits)
{
    m_ranges = ranges;
    m_modeSpeedLimits = modeSpeedLimits;
    for (auto it = ranges.cbegin(); it != ranges.cend(); ++it)
        sendJson({{"command","set_range"},{"parameter",it.key()},{"min",it.value().minimum},{"max",it.value().maximum}});
    for (auto it = modeSpeedLimits.cbegin(); it != modeSpeedLimits.cend(); ++it)
        sendJson({{"command","set_mode_speed_limit"},{"mode",it.key()},{"limit",it.value()}});
    m_gauge->setMaximum(m_ranges["speed"].maximum);
    applyModeTheme(m_currentMode);
}

void MainWindow::startSimulation() { sendJson({{"command","start"}}); }
void MainWindow::stopSimulation() { sendJson({{"command","stop"}}); }
void MainWindow::setMode(const QString &mode)
{
    const QString upper = mode.toUpper();
    applyModeTheme(upper);
    sendJson({{"command","set_mode"},{"mode",upper}});
}

void MainWindow::updateConnectionStatus(const QString &text, bool good)
{
    m_statusLabel->setText(text);
    m_statusLabel->setObjectName(good ? "statusGood" : "statusBad");
    m_statusLabel->style()->unpolish(m_statusLabel); m_statusLabel->style()->polish(m_statusLabel);
}

void MainWindow::serialError(QSerialPort::SerialPortError error)
{
    if (error != QSerialPort::NoError) updateConnectionStatus("UART ERROR: " + m_serial.errorString(), false);
}
