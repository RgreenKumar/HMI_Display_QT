# EV HMI Dashboard – Qt Frontend + Python UART Backend

This project implements a dark automotive HMI inspired by the reference screenshot:
- Large central semicircular speed gauge
- Red gauge arc
- ECO / POWER / CRUISE drive modes
- RANGE / ODO / TRIP information
- Time and battery indicators
- Settings button
- Per-parameter minimum/maximum range configuration
- Python backend generates random values only inside configured ranges
- Qt frontend and Python backend communicate using newline-delimited JSON over UART/serial

## 1. Project structure

```text
ev_hmi_dashboard/
├── qt_frontend/
│   ├── CMakeLists.txt
│   ├── main.cpp
│   ├── mainwindow.h
│   ├── mainwindow.cpp
│   ├── gaugewidget.h
│   ├── gaugewidget.cpp
│   ├── settingsdialog.h
│   └── settingsdialog.cpp
├── python_backend/
│   ├── backend.py
│   └── requirements.txt
└── README.md
```

## 2. Communication protocol

Qt -> Python:

```json
{"command":"set_range","parameter":"speed","min":20,"max":60}
```

Python -> Qt:

```json
{"type":"telemetry","speed":43.2,"rpm":2850,"temperature":61.3,"battery":12.8,"fuel":72.0,"pressure":31.4,"range":50.0,"odo":200.0,"trip":40.0}
```

Qt -> Python:

```json
{"command":"set_mode","mode":"POWER"}
```

Qt -> Python:

```json
{"command":"reset_trip"}
```

## 3. Install Qt on Ubuntu/Debian

```bash
sudo apt update
sudo apt install qt6-base-dev qt6-base-dev-tools cmake g++ pkg-config socat python3 python3-pip
```

If your Linux distribution uses Qt5, this project should be ported to Qt5 by changing the CMake package from Qt6 to Qt5.

## 4. Install Python dependency

```bash
cd python_backend
python3 -m pip install -r requirements.txt
```

The backend uses `pyserial`.

## 5. Development without physical UART hardware

A single serial device cannot normally be opened by both programs at the same time. For PC-only development, create a virtual serial pair:

```bash
socat -d -d pty,raw,echo=0 pty,raw,echo=0
```

It prints two device names, for example:

```text
/dev/pts/5
/dev/pts/6
```

Run the Python backend on one end:

```bash
python3 python_backend/backend.py --port /dev/pts/5 --baud 115200
```

Build and run Qt using the other:

```bash
cmake -S qt_frontend -B qt_frontend/build
cmake --build qt_frontend/build -j$(nproc)

./qt_frontend/build/EVHmiDashboard --port /dev/pts/6 --baud 115200
```

If the device names change after restarting `socat`, use the new names.

## 6. Physical UART

For a real embedded system, use two serial endpoints connected correctly according to your hardware design:

- Qt side: the UART/USB-serial interface available to the HMI application.
- Python side: the UART/USB-serial interface used by the backend.
- Common GND is required for typical TTL UART wiring.
- TX of one side goes to RX of the other side and vice versa.
- Do NOT connect TTL UART directly to RS-232 voltage levels.

Example:

```text
Qt HMI /dev/ttyUSB0  <---- UART ---->  Python /dev/ttyUSB1
```

Use the actual device names on your target.

## 7. Change ranges from the HMI

Click `SETTINGS`.

Each parameter has:

```text
MIN VALUE       MAX VALUE
```

Example:

```text
Speed          20       60
RPM            1000     4000
Temperature    30       80
Battery        11.5     14.5
Fuel           20       100
Pressure       20       40
```

Click `APPLY`.

The Qt frontend sends the new range to Python. The Python backend immediately uses that range for future random values.

## 8. Important validation

The settings dialog prevents:

- non-numeric input
- minimum >= maximum
- empty fields

The Python backend also validates ranges before accepting them. This means a bad UI value cannot silently create an invalid simulation range.

## 9. How random values are generated

The backend uses:

```python
random.uniform(min_value, max_value)
```

for floating-point parameters and:

```python
random.randint(min_value, max_value)
```

for integer-like parameters.

Every generated value is therefore constrained by the active range.

## 10. Running order

Recommended order:

1. Start UART / virtual UART.
2. Start Python backend.
3. Start Qt HMI.
4. Click SETTINGS and configure ranges.
5. Click APPLY.
6. Use START/STOP to control telemetry updates.
7. Select ECO / POWER / CRUISE.

The HMI will show live generated values.

## 11. Troubleshooting

### No telemetry
Check that both applications use the correct two ends of the serial pair and the same baud rate.

### Permission denied on /dev/ttyUSB*
Try:

```bash
sudo usermod -aG dialout $USER
```

Then log out and log in again.

### Qt cannot find Qt6
Check:

```bash
qmake6 --version
```

and:

```bash
cmake --find-package -DNAME=Qt6 -DCOMPILER_ID=GNU -DLANGUAGE=CXX -DMODE=EXIST
```

### Backend cannot open serial port

```bash
python3 -m serial.tools.list_ports
```

Use the correct device path.

## 12. Design note

The UI intentionally uses a custom QPainter gauge rather than an image of a gauge. That keeps the speed needle and scale dynamic and makes the design usable with any configured speed range.
